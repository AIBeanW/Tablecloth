document.title="桌布"
window.console.log("hello firefox")
setInterval(()=>{document.title="桌布"},1000)